// Online C++ compiler (editor)
// Write and run C++ online using this editor.
/*Write a program using switch in which case 2 asks the user to enter a number. Inside case 2, use an if statement to check if the number is divisible by 10. If the condition is true, display “Number is Multiple of 10.” Otherwise, do not display anything..*/
#include <iostream>
using namespace std;
int main()
{
    int choice, num;
    cout << "2. Multiple of 10 Check\n";
    cout << "Enter choice: ";
    cin >> choice;
    switch(choice)
        {
        case 2:
            cout << "Enter a number: ";
            cin >> num;
            if (num % 10 == 0) 
            {
                cout << "Number is Multiple of 10.";
            }
            break;
        default:
            cout << "Invalid choice.";
    }
}

