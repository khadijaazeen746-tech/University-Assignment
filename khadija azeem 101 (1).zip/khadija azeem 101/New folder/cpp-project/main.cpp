// Online C++ compiler (editor)
// Write and run C++ online using this editor.
/*Take the bill amount and is_member (1 or 0) as input. If the bill is 3000 or more or the customer is a member, print "Free delivery"...*/
#include <iostream>
using namespace std;
int main()
{
   int bill;
   bool is_member;
   cout<<"Enter your bill:"<<endl;
    cin>>bill;
   cout<<"Enter is_member:"<<endl;
   cin>>is_member;
   if(bill>=3000||is_member)
   cout<<"Free Delivery ";
    return 0;
}
