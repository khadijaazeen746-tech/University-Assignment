// Online C++ compiler (editor)
// Write and run C++ online using this editor.
//Write a program that asks the user to enter a password. If the password equals "1234", print "Access granted",otherwise print"Access not granted".
#include <iostream>
using namespace std;
int main() 
{
    int x=1234;
    int num;
    cout<<"Enter a number:";
    cin>>num;
    if(num==x)
    {
        cout<<" Access granted";
    }
 else
    {
     cout<<"Access not granted";
    }
}
